create PROCEDURE calculate_average_cost
AS
    v_codprod           INTEGER;
    v_codemp            INTEGER;
    v_dtentsai          DATE;
    v_atualestoque      INTEGER;
    v_estoque_acumulado INTEGER;
    v_total_cost        NUMBER := 0;
    v_total_quantity    NUMBER := 0;
    v_vlrtot            NUMBER;
    v_qtdneg            NUMBER;
    v_average_cost      NUMBER;
    v_data_inicial      DATE;
    v_data_final        DATE;
    cursor c_inventory is
        SELECT CODPROD, CODEMP, DTENTSAI, ATUALESTOQUE, ESTOQUE_ACUMULADO, VLRTOT, QTDNEG
        FROM HVL_MOVIMENTO_ESTOQUE
        WHERE ATUALESTOQUE = 1
        ORDER BY DTENTSAI;
BEGIN
    open c_inventory;
    loop
        fetch c_inventory into v_codprod, v_codemp, v_dtentsai, v_atualestoque, v_estoque_acumulado, v_vlrtot, v_qtdneg;
        exit when c_inventory%notfound;
        if v_estoque_acumulado = 0 then
            v_data_inicial := v_dtentsai;
        else
            v_data_final := v_dtentsai;
            v_total_cost := v_total_cost + v_vlrtot;
            v_total_quantity := v_total_quantity + v_qtdneg;
        end if;
        if v_estoque_acumulado <> 0 then
            v_average_cost := v_total_cost / v_total_quantity;
            update HVL_MOVIMENTO_ESTOQUE
            set custo_medio_ponderado = v_average_cost
            where CODPROD = v_codprod
              and CODEMP = v_codemp
              and dtentsai >= v_data_inicial
              and dtentsai <= v_data_final;
            v_total_cost := 0;
            v_total_quantity := 0;
        end if;
    end loop;
    close c_inventory;
    dbms_output.put_line('Custo médio ponderado calculado com sucesso!');
END;
/

