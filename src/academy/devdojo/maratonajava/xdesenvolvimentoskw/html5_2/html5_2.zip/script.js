function abrirNivelImplementadoExternamente (idNivel) {
    abrirNivel (idNivel, []);

}
